/* 
 * omega.c -- handles:
 * advanced modules for eggdrop (Aug 20 2000) -djmc
 *
 * This file contain private features for eggdrop bot  
 * private unpublished source code for omega botpack 
 */

#if HAVE_CONFIG_H
#include <config.h>
#endif
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <ctype.h>
#include <varargs.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include "eggdrop.h"
#include "proto.h"
#include "users.h"
#include "chan.h"
#include "tclegg.h"
#include "cmdt.h"

#define BUFSIZE 512
#define HANDLEN 9
char TBUF[1024];
extern struct dcc_t dcc[];
extern char botnetnick[];
extern char myip[], hostname[], version[];
extern char botname[];
extern int modesperline, serv;

static char md5out[40];

char *strfry(char *string);
extern Tcl_Interp *interp;
void createkey(char *s, int x, int type)
{     
   register int i, r;
   context;
   srandom((x + type) % 65536);

   for (i = 0; i != 16; i++) {
      r = ((random() + i) % 7);
      switch (r) {
    case 0:
       s[i] = ':' + (random() % 4);
       break;
    case 1:
       s[i] = '0' + (random() % 5);
       break;
    case 2:
       s[i] = 'a' + (random() % 3);
       break;
    case 3:
       s[i] = '!' + (random() % 4);
       break;
    case 4:
       s[i] = '0' + (random() % 2);
       break;
    case 5:
       s[i] = '(' + (random() % 6);
       break;
    case 6:
       s[i] = 'A' + (random() % 7);
       break;
    default:
       fatal("Programming Error: ", errno);
      }
   }
   s[15] = 0;
}
void findkey(char *s, int x)
{
   createkey(s, x, 0);
}
void efgets(char *s, int keybase, int size, FILE * stream)
{
   register char *dec, *p;
   char key[16];
   char buffer[size];
   if (fgets(buffer, size, stream) == NULL)
      return;
   if (feof(stream))
      return;
   p = strchr(buffer, '\n');
   if (p != NULL)
      *p = 0;
   findkey(key, keybase);
   dec = decrypt_string(key, buffer);
   strncpy(s, dec, size - 1);
   strcat(s, "\n");
   memset(key, 0, 16);
   //strfry(dec);
   nfree(dec);
}
int DecryptFile2Buffer(char *in, char *outbuf)
{
   FILE *fin;
   char buf[BUFSIZ];
   int count = 0;
   fin = fopen(in, "r");
   if (fin == NULL)
      return 0;
   count++;
   while (!feof(fin)) {
      efgets(buf, count, BUFSIZ, fin);
      if (feof(fin))
    break;
      strcat(outbuf, buf);
      count++;
   }
   fclose(fin);
   return 1;
}
void efprintf(va_alist)
va_dcl
{
   char *format, *enc, key[16], *p;
   FILE *fp;
   int keybase;
   va_list va;
   static char buffer[BUFSIZ];
   va_start(va);
   fp = va_arg(va, FILE *);
   keybase = va_arg(va, int);
   format = va_arg(va, char *);
   vsnprintf(buffer, BUFSIZ, format, va);
   p = strchr(buffer, '\n');
   if (p != NULL)
      *p = 0;
   findkey(key, keybase);
   if ((enc = encrypt_string(key, buffer)) == NULL)
      fatal("OH FUCK", 0);
   fputs(enc, fp);
   fputc('\n', fp);
#ifdef TESTING
   fputs(buffer, stdout);
   fputc('\n', stdout);
#endif
   bzero(key, 16);
   memset(enc, 0, sizeof(enc));
   nfree(enc);
   va_end(va);
}
int EncryptFile(char *in, char *out)
{
   FILE *fin, *fout;
   char buf[BUFSIZ];
   int count = 0;
   fin = fopen(in, "r");
   if (fin == NULL)
      return 0;
   fout = fopen(out, "w");
   if (fout == NULL) {
      fclose(fin);
      return 0;
   }
   context;
   while ((fgets(buf, BUFSIZ, fin)) != NULL) {
      if (feof(fin))
    break;
      if (buf[0] != '\n') {
    count++;
    efprintf(fout, count, buf);
      }
   }
   fclose(fin);
   fclose(fout);
   chmod(out, 0600);
   return (count * BUFSIZ);
}
int esource PROTO1(char *, fname)
{
   int code;
   FILE *f;
   struct stat st;
   f = fopen(fname, "r");
   if (f == NULL)
      return 0;
   fclose(f);
   context;
   stat(fname, &st);
   {
      char buffer[((long) st.st_size * 2) + BUFSIZ];
      strncpy(buffer, "", 2); // <--- this is a must !
      if (!DecryptFile2Buffer(fname, buffer)) {
          putlog(LOG_MISC, "*", "Decryption error in file '%s':", fname);
          return 0;
      }
      context;
      Tcl_SetVar(interp, "errorInfo", "-", TCL_GLOBAL_ONLY);
      code = Tcl_Eval(interp, buffer);
      context;
      if (code != TCL_OK) {
         putlog(LOG_MISC, "*", "Tcl error in file '%s':%d\n", fname, interp->errorLine);
      putlog(LOG_MISC, "*", "%s\n", Tcl_GetVar(interp,"errorInfo",TCL_GLOBAL_ONLY));
      }
   }
   return 1;
}

extern int EncryptFile(char *in, char *out);
#define PARSE_FLAGS "euv"
void omega_arg (int argc, char *argv[])
{
   int i;
   char *p, *m;
   char gpasswd[121];
   while ((i = getopt(argc, argv, PARSE_FLAGS)) != EOF) {
         switch (i) {
         case 'e':
            printf("* Enter encryption password: ");
            gets(gpasswd);
            printf("\n");
            m = MD5Data(gpasswd, strlen(gpasswd), md5out);
            if (strcmp(ENCPASS, m) != 0)
              fatal("incorrect password.",0);
            if (argc == 4) {
              context;
              if (EncryptFile(argv[2],argv[3])) 
                 fatal("File Encryption complete",3);
              fatal("Error Encrypting FILE", 1);
            }
            fatal("usage: omega -e <infile> <outfile>",3);
            break;
	case 'u':
            printf("* Enter encryption password: ");
            gets(gpasswd);
            printf("\n");
            m = MD5Data(gpasswd, strlen(gpasswd), md5out);
            if (strcmp(ENCPASS, m) != 0)
              fatal("incorrect password.",0);
            if (argc == 4) {
              context;
              if (!cryptit(argv[2],argv[3])) 
                 fatal("File Encryption complete",3);
              fatal("Error Encrypting FILE", 1);
            }
            fatal("usage: omega -u <infile> <outfile>",3);
            break;
         default:
            break;	
      }
  }
}
void init_bin(char *argv[])
{
   printf("%s-%s (c)2000 djmc\n", PACKNAME, PACKVERS);
   context;
   printf("\ncontinuing load...\n");
   return;
}

extern char chanfile[7], notefile[7], userfile[7];

void init_omega()
{
   int code;
   FILE *f;
   struct stat st;
   strncpy(userfile, "user.o", 7);
   strncpy(notefile, "note.o", 7);
   strncpy(chanfile, "chan.o", 7);
   Tcl_SetVar(interp, "tcl_path", "omega.tcl", TCL_GLOBAL_ONLY);
   Tcl_SetVar(interp, "egg_path", "omega", TCL_GLOBAL_ONLY);
   Tcl_SetVar(interp, "usr_path", "user.o", TCL_GLOBAL_ONLY);
   f = fopen("omega.tcl", "r");
   if (f == NULL)
      fatal("ERROR: TCL NOT FOUND", 0);
   fclose(f);
   context;
   stat("omega.tcl", &st);
   {
      char buffer[((long) st.st_size * 2) + BUFSIZ];
      strncpy(buffer, "", 2); // <--- this is a must !
      if (!DecryptFile2Buffer("omega.tcl", buffer)) {
          putlog(LOG_MISC, "*", "Decryption error in file '%s':", "omega.tcl");
          fatal("decryption error", 0);
      }
      context;
      Tcl_SetVar(interp, "errorInfo", "-", TCL_GLOBAL_ONLY);
      code = Tcl_Eval(interp, buffer);
      context;
      if (code != TCL_OK) {
         putlog(LOG_MISC, "*", "Tcl error in file '%s':%d\n", "omega.tcl", interp->errorLine);
         putlog(LOG_MISC, "*", "%s\n", Tcl_GetVar(interp, "errorInfo", TCL_GLOBAL_ONLY));
      }
   }
}

void init_binfile(char *argv[])
{
   printf("%s-%s (c)2000 djmc\n", PACKNAME, PACKVERS);
   return;
}

int xprintf();
void my_bzero();

void massdeop(char *ch)
{
   memberlist *m;
   struct chanset_t *chan;
   char s[NICKLEN + UHOSTLEN + 1] = "";
   char handle[HANDLEN] = "*";
   char nicks[(NICKLEN * modesperline) + modesperline];
   char modes[7] = "";
   char buffer[BUFSIZE] = "";
   char buf[(BUFSIZE / modesperline)];
   int i = 0, total = 0;
   int burst = (BUFSIZE / (6 + strlen(ch) + (modesperline * NICKLEN) + (modesperline * 2)));
   // putlog(LOG_DEBUG, "*", "burst = %d", burst);
   return;
   context;
   chan = findchan(ch);
   if (chan == NULL)
      return;
   if (!me_op(chan))
      return;
   for (i = 0; i < modesperline; i++)
      strcat(modes, "o");
   strcpy(nicks,"");
   strcpy(buf,"");
   m = chan->channel.member;
   while (m->nick[0]) {
      if (member_op(chan->name, m->nick))
	 if (strcmp(m->nick, botname) != 0) {
	    sprintf(s, "%s!%s", m->nick, m->userhost);
	    get_handle_by_host(handle, s);
	    if (!op_anywhere(handle)) {
	       if (i < modesperline) {
		  sprintf(s, "%s ", m->nick);
		  strcat(nicks, s);
		  i++;
	       }
	       if (i == modesperline) {
		  i = 0;
		  total++;
		  sprintf(buf, "MODE %s -%s %s\n", ch, modes, nicks);
		  strncat(buffer, buf, BUFSIZE);
	       }
	       if (total >= burst) {
		  xprintf(serv, buffer);
		  total = 0;
	       }
	    }
	 }
      m = m->next;
   }
   if (buffer[0])
      xprintf(serv, buffer);
   if ((i > 0) && (nicks[0]))
      xprintf(serv, "MODE %s -%s %s\r\n", ch, modes, nicks);
}