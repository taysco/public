/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if on AIX 3.
   System headers sometimes define this.
   We just want to avoid a redefinition error message.  */
#ifndef _ALL_SOURCE
/* #undef _ALL_SOURCE */
#endif

/* Define if you have <sys/wait.h> that is POSIX.1 compatible.  */
#define HAVE_SYS_WAIT_H 1

/* Define if on MINIX.  */
/* #undef _MINIX */

/* Define to `int' if <sys/types.h> doesn't define.  */
/* #undef pid_t */

/* Define if the system does not provide POSIX.1 features except
   with this defined.  */
/* #undef _POSIX_1_SOURCE */

/* Define if you need to in order for stat and other things to work.  */
/* #undef _POSIX_SOURCE */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if you can safely include both <sys/time.h> and <time.h>.  */
#define TIME_WITH_SYS_TIME 1

/* Define if you have the getdtablesize function.  */
#define HAVE_GETDTABLESIZE 1

/* Define if you have the getrusage function.  */
#define HAVE_GETRUSAGE 1

/* Define if you have the random function.  */
#define HAVE_RANDOM 1

/* Define if you have the rename function.  */
#define HAVE_RENAME 1

/* Define if you have the dprintf function  */
#define HAVE_DPRINTF 1

/* Define if you have the sigaction function.  */
#define HAVE_SIGACTION 1

/* Define if you have the sigemptyset function.  */
#define HAVE_SIGEMPTYSET 1

/* Define if you have the srandom function.  */
#define HAVE_SRANDOM 1

/* Define if you have the vsprintf function.  */
#define HAVE_VSPRINTF 1

/* Define if you have the waitpid function.  */
/* #undef HAVE_WAITPID */

/* Define if you have the setpgid function. */
#define HAVE_SETPGID 1

/* Define if you have the clock function. */
#define HAVE_CLOCK 1

/* Define if you have the <dirent.h> header file.  */
#define HAVE_DIRENT_H 1

/* Define if you have the <ndir.h> header file.  */
/* #undef HAVE_NDIR_H */

/* Define if you have the <sys/dir.h> header file.  */
/* #undef HAVE_SYS_DIR_H */

/* Define if you have the <sys/ndir.h> header file.  */
/* #undef HAVE_SYS_NDIR_H */

/* Define if you have the <sys/rusage.h> header file.  */
/* #undef HAVE_SYS_RUSAGE_H */

/* Define if you have the <sys/select.h> header file.  */
#define HAVE_SYS_SELECT_H 1

/* Define if you have the <sys/time.h> header file.  */
#define HAVE_SYS_TIME_H 1

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Define if running on OSF/1 platform. */
/* #undef STOP_UAC */

/* Define if you need strcasecmp */
#define HAVE_STRCASECMP 1

/* Define if running on Linux with thread support. */
/* #undef LINUX_THREADS */

/* define if running on Linux and need to watch for byteorder headers */
/* #undef LINUX */

/* define if big-endian chipset */
/* #undef WORDS_BIGENDIAN */

/* we may need dlopen now (modules) so include it */
#define HAVE_DLOPEN 1

/* this willl get defined if modules will work on your system */
#define MODULES_OK 1

/* sunos 4.0 *sigh* */
/* #undef DLOPEN_MUST_BE_1 */ 

/* assume nothing */
#define SIZEOF_INT 4
#define SIZEOF_LONG 4
