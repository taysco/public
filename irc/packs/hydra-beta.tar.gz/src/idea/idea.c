#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "idea.h"

unsigned char key[16]= "@123456789abcde@";
static unsigned char cfb_iv[8]={0x34,0x12,0x78,0x56,0xab,0x90,0xef,0xcd};
/*
static int cfb64_test(cfb_cipher)
unsigned char *cfb_cipher;
        {
        IDEA_KEY_SCHEDULE eks,dks;
        int err=0,i,n;

        idea_set_encrypt_key(key,&eks);
        idea_set_decrypt_key(&eks,&dks);
        memcpy(cfb_tmp,cfb_iv,8);
        n=0;
        idea_cfb64_encrypt(plain, cfb_buf1, (long)12, &eks,cfb_tmp,&n,IDEA_ENCRYPT);
}

  */